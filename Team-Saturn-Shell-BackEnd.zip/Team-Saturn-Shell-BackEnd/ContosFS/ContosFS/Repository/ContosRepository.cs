﻿using ContosFS.Data;
using ContosFS.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContosFS.Repository
{
    public class UserRepository
    {
        public ContosDbContext _UserDbContext;
        public IEnumerable<UserEntity> UserEntities { get; set; }

        public UserRepository(ContosDbContext dbContext)
        {
            _UserDbContext = dbContext;
        }

         public IEnumerable<UserEntity> GetUser()
        {
            return _UserDbContext.UserEntities;
        }
    }

    public class StockRepository
    {
        public ContosDbContext _StockDbContext;
        public IEnumerable<StockEntity> StockEntities { get; set; }

        public StockRepository(ContosDbContext dbContext)
        {
            _StockDbContext = dbContext;
        }
        public IEnumerable<StockEntity> GetStock()
        {
            return _StockDbContext.StockEntities;
        }
    }
    
    public class HoldingsRepository
    {
        public ContosDbContext _HoldingsDbContext;
        public IEnumerable<HoldingsEntity> HoldingsEntities { get; set; }

        public HoldingsRepository(ContosDbContext dbContext)
        {
            _HoldingsDbContext = dbContext;
        }
        public IEnumerable<HoldingsEntity> GetHoldings()
        {
            return _HoldingsDbContext.HoldingsEntities;
        }
    }

    public class TransactionsRepository
    {
        public ContosDbContext _TransactionsDbContext;
        public IEnumerable<TransactionsEntity> TransactionsEntities { get; set; }

        public TransactionsRepository(ContosDbContext dbContext)
        {
            _TransactionsDbContext = dbContext;
        }
        public IEnumerable<TransactionsEntity> GetTransaction()
        {
            return _TransactionsDbContext.TransactionsEntities;
        }
    }
}
