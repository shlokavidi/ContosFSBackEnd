﻿using ContosFS.Data.Entity;
using ContosFS.Data.GraphQL.Type;
using ContosFS.Repository;
using GraphQL;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContosFS.Data.GraphQL
{
    public class ContosMutation: ObjectGraphType
    {
        public ContosMutation (UserRepository _userRepository,
            StockRepository _stockRepository,
            HoldingsRepository _holdingsRepository,
            TransactionsRepository _transactionsRepository)
        {
            base.Field<UserType>(
                "addUser",
                arguments: new QueryArguments(
                    new QueryArgument<NonNullGraphType<UserInputType>> { Name = "user"}),
                resolve: context =>
                {
                    var user = context.GetArgument<UserEntity>("user");
                    return _userRepository.AddUser(user);
            
                });      
        }
    }
}
