﻿using ContosFS.Data;
using ContosFS.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContosFS.Repository
{
    public class UserRepository
    {
        public ContosDbContext _UserDbContext;
        public IEnumerable<UserEntity> UserEntities { get; set; }

        public UserRepository(ContosDbContext dbContext)
        {
            _UserDbContext = dbContext;
        }

         public IEnumerable<UserEntity> GetUser()
        {
            return _UserDbContext.UserEntities;
        }

        public UserEntity GetUserWith(int id)
        {
            return _UserDbContext.UserEntities.First(s => s.UserId == id);

        }
        public UserEntity AddUser(UserEntity user)
        {
            this._UserDbContext.UserEntities.Add(user);
            this._UserDbContext.SaveChanges();
            return user;
        }

        internal object GetHoldingsWith(int userid, int stockid)
        {
            throw new NotImplementedException();
        }
    }

    public class StockRepository
    {
        public ContosDbContext _StockDbContext;
        public IEnumerable<StockEntity> StockEntities { get; set; }

        public StockRepository(ContosDbContext dbContext)
        {
            _StockDbContext = dbContext;
        }
        public IEnumerable<StockEntity> GetStock()
        {
            return _StockDbContext.StockEntities;
        }
        
    }
    
    public class HoldingsRepository
    {
        public ContosDbContext _HoldingsDbContext;
        public IEnumerable<HoldingsEntity> HoldingsEntities { get; set; }

        public HoldingsRepository(ContosDbContext dbContext)
        {
            _HoldingsDbContext = dbContext;
        }
        public IEnumerable<HoldingsEntity> GetHolding()
        {
            return _HoldingsDbContext.HoldingsEntities;
        }
        public HoldingsEntity GetHoldingsWith(int userid, int stockid)
        {
            return _HoldingsDbContext.HoldingsEntities.First(s => s.UserId == userid && s.StockId == stockid);

        }
    }

    public class TransactionsRepository
    {
        public ContosDbContext _TransactionsDbContext;
        public IEnumerable<TransactionsEntity> TransactionsEntities { get; set; }

        public TransactionsRepository(ContosDbContext dbContext)
        {
            _TransactionsDbContext = dbContext;
        }
        public IEnumerable<TransactionsEntity> GetTransaction()
        {
            return _TransactionsDbContext.TransactionsEntities;
        }
    }
}
